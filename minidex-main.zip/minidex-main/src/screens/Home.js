import React from 'react';
import HomeScreen from './HomeScreen';
export default function Home(){
    return <div>
                <HomeScreen>
                    
                </HomeScreen>
            </div>
}